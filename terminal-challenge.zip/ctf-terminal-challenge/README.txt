Welcome to the Terminal Challenge!
======================================

Your mission: navigate this archive and find the hidden flag.

Start here: read the files in the clues/ folder.
They will point you toward the flag.

Commands you will need:
  ls          - list files in the current directory
  cd folder   - move into a folder
  cat file    - read a file
  ls -R       - list ALL files recursively (shows everything at once)

Good luck!
